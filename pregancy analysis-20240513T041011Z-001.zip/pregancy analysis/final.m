clc
clear all
warning off all
while(1)
    ip=menu('Epilepsy During Pregnancy','Good Pregnancy','Abortion','Exit');
if ip==3
    break
end
if ip==1
    main
end
if ip==2
    main1
end
end