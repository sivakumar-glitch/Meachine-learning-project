    clc
clear all
close all
warning off all
while(1)
    ip=menu('Abortion Analysis','Abortion analysis with Age','Abortion analysis with drugs',...
        'Women condition analysis with Drugs','Exit');
    if ip==4
        break
    end
    if ip==1
system_dependent('DirChangeHandleWarn','never');
addpath(genpath('.'))
[~,~,age]=xlsread('NEW ABORTION.xlsx','D1:D24');
[~,~,Delivery_status]=xlsread('NEW ABORTION.xlsx','H1:H24');
age1=[];
for i=2:20
    a=age(i,:);
    a1=a{:};
    age1=vertcat(age1,a1);
end
Delivery_status1=[];
for i=2:20
    a=Delivery_status(i,:);
    a1=a{:};
    Delivery_status1=vertcat(Delivery_status1,a1);
end
data=[age1,Delivery_status1];
for i1=1:inf
[C, I, iter] = Kmeans(data,2);
ch=I(end,:);
if ch==1
    I=I;
data1=data(:,1);
for i=1:2
    data1=data(:,1);
    a=find(I==i);
    a1=data1(a,:);
    b=find(a1>=30);
    b1=find(data1>=30);
    a1(b)=[];
    data1(b1)=[];
    [m n]=size(b);
    [m1 n1]=size(b1);
    perc1=(m/m1)*100;
    %%%%%%
    b=find(a1>=25);
    b1=find(data1>=25);
    a1(b)=[];
    data1(b1)=[];
    [m n]=size(b);
    [m1 n1]=size(b1);
    perc2=(m/m1)*100;

    if i==1
    perc_norm=[perc2,perc1];
    else
        perc_cea=[perc2,perc1];
    end
end
disp(strcat('Maximum Abortion at Age  :  25 - 30 ---  ',num2str(perc_norm(:,1))))
disp(strcat('Maximum Abortion at Age  :  30 - 35 ---  ',num2str(perc_norm(:,2))))
 disp(strcat('Mainimum Abortion at Age  :  25 - 30 ---  ',num2str(perc_cea(:,1))))
disp(strcat('Minimum Abortion at Age  :  30 - 35 ---  ',num2str(perc_cea(:,2))))  

ages={'Age limit :  25 - 30','Age limit :  30 - 35',};
grpn={'maximum','minimum'};
 tabfig= figure('name','Abortion Analysis wth Age','numbertitle','off','Position',[200 200 850 300]);
            dat = [perc_norm(:) perc_cea(:)];
            uitable('Parent',tabfig,'Data',dat,'ColumnName',grpn,'RowName',ages,'ColumnWidth',{100},'Position',[20 20 800 250]);
break
end
end
end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if ip==2

delivery_status=xlsread('NEW ABORTION.xlsx','H2:H24');
drug=xlsread('NEW ABORTION.xlsx','J2:J24');
perc=[];
 drug_name={'Carbamazepine','Clobazam','sodiuum Valporate','phenytoin',...
      'phenoibarbitone'};
for i=1:5
   a=find(drug==i); 
   [m n]=size(a);
   m1=length(drug);
   per=(m/m1)*100;
   perc=cat(2,perc,per);
   string=drug_name(:,i);
  str={' Abortion Rate --'};
  disp(strcat(string,str,num2str(per),'%'));
end
 
%   string=drug_name(:,i);
%   str={'Abortion Rate'}
%   disp(strcat(string,str,num2str(perc),'%'));
%   
grpn={'Abortion Rate'};
 tabfig= figure('name','Abortion Analysis wth Drugs','numbertitle','off','Position',[200 200 850 300]);
            dat = [perc(:)];
            uitable('Parent',tabfig,'Data',dat,'ColumnName',grpn,'RowName',drug_name,'ColumnWidth',{100},'Position',[20 20 800 250]);
 
            fi=[0 0 0 0 0 ;perc;0 0 0 0 0];
figure('name','Abortion Rate  comparison','numbertitle','off')
bar(fi)
axis([1,3,0,50])
set(gca,'xticklabel',{'','',''})
xlabel('Drugs')
ylabel('Values in %')
legend('Carbamazepine','Clobazam','sodiuum Valporate','phenytoin',...
      'phenoibarbitone','location','best')

    
    
    
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if ip==3
    drugnames={'Carbamazepine','Clobazam','sodiuum Valporate','phenytoin',...
      'phenoibarbitone'};
    drug_name=xlsread('NEW ABORTION.xlsx','J2:J24');
    out1=xlsread('NEW ABORTION.xlsx','N2:N24');
    data1=[drug_name,out1];
fit=[];
ab=[];
for i=1:5
 data2=data1(:,1);
 a=find(data2==i);
 a1=data1(a,:);
 size(a);
[m n]=size(a1);
b=a1(:,2);
b1=find(b==0);
b2=find(b==1);
[m1 n1]=size(b1);
[m2 n2]=size(b2);
perc=(m1/m)*100; 
perc1=(m2/m)*100;
string=drugnames(:,i);
str={'Fit Free percentage is : '};
str1={'Abnormal percentage is : '};
disp(strcat(string,str,num2str(perc))) 
disp(strcat(string,str1,num2str(perc1)))
ab=vertcat(ab,perc1);
fit=vertcat(fit,perc);
end

grpn={'Fit Free','Abnormal'};
 tabfig= figure('name','Women Condition Anaysis with Drugs','numbertitle','off','Position',[200 200 850 300]);
            dat = [fit(:) ab(:)];
            uitable('Parent',tabfig,'Data',dat,'ColumnName',grpn,'RowName',drugnames,'ColumnWidth',{100},'Position',[20 20 800 250]);

    
end
end

